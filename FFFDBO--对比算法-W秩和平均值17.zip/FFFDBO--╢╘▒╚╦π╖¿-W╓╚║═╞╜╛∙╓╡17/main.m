%%
%%画出各个算法的平均值，最优值，等指标，并计算其W秩，
clear
clc
close all
addpath(genpath(pwd));
pop_size=50;   %种群数目
max_FES=300000;   %迭代次数

run =30;
box_pp =0;  %
RESULT=[];   %统计标准差，平均值，最优值等结果
rank_sum_RESULT=[];  %统计秩和检验结果
dim =30;
% Load details of the selected benchmark function

F = [1 3 4 5 6 7 8 9 10 11 12 13 14 15];
% F =[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30];
%  F = [1 2 3 4 ];
if box_pp ==1
    figure('Name', '箱型图', 'Color', 'w','Position', [50 50 1400 700])
end

for func_num = 1:length(F)    %CEC2005有23个函数
   
    % Display the comprehensive results
    disp(['F',num2str(F(func_num)),'函数计算结果：'])
    % [lower_bound,upper_bound,variables_no,fhd]=Get_Functions_cec2017(['F',num2str(F(func_num))],dim);
     [lower_bound,upper_bound,variables_no,fhd]=Get_Functions_cec2017(F(func_num),dim);

    resu = [];  %统计标准差，平均值，最优值等结果
    rank_sum_resu = [];   %统计秩和检验结果
    box_plot = [];  %统计箱型图结果
    %% Run the FFFDBO algorithm for "run" times
    for nrun=1:run
        [position,final,iter]=FFFDBO(pop_size,max_FES,lower_bound,upper_bound,variables_no,fhd);
        final_main(nrun)=final;
        z1(nrun) =  final;
    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [mean(final_main);std(final_main);min(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    disp(['FFFDBO：平均值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 最优值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);
   %% Run the WOA algorithm for "run" times
    for nrun=1:run
        [position,final,iter]=MDBO(pop_size,max_FES,lower_bound,upper_bound,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;

    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [mean(final_main);std(final_main);min(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['MDBO：平均值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 最优值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);
    % 
    
    
%% Run the WOA algorithm for "run" times
    for nrun=1:run
        [position,final,iter]=GODBO(pop_size,max_FES,lower_bound,upper_bound,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;

    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [mean(final_main);std(final_main);min(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['GODBO：平均值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 最优值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);




    %% Run the BFO algorithm for "run" times
    for nrun=1:run
        [position,final,iter]=QHDBO2(pop_size,max_FES,lower_bound,upper_bound,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;

    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [mean(final_main);std(final_main);min(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['QHDBO：平均值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 最优值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);

 %% Run the DBO algorithm for "run" times
    for nrun=1:run
        [position,final,iter]=DBO(pop_size,max_FES,lower_bound,upper_bound,variables_no,fhd);
        final_main(nrun)=final;
        z2(nrun) =  final;

    end
    box_plot = [box_plot;final_main]; %统计箱型图结果
    zz = [mean(final_main);std(final_main);min(final_main);median(final_main);max(final_main)];
    resu = [resu,zz];
    rs = ranksum(z1,z2);
    if isnan(rs)  %当z1与z2完全一致时会出现NaN值，这种概率很小，但是要做一个防止报错
        rs=1;
    end
    rank_sum_resu = [rank_sum_resu,rs]; %统计秩和检验结果
    disp(['DBO：平均值:',num2str(zz(1)),' 标准差:',num2str(zz(2)),' 最优值:',num2str(zz(3)),' 中值:',num2str(zz(4)),' 最差值:',num2str(zz(5))]);


    rank_sum_RESULT = [rank_sum_RESULT;rank_sum_resu];  %统计秩和检验结果
    RESULT = [RESULT;resu];   %统计标准差，平均值，最优值等结果
    
    %% 绘制箱型图
    if box_pp == 1 
        subplot(4,6,func_num)  %4行6列
        mycolor = [0.862745098039216,0.827450980392157,0.117647058823529;...
        0.705882352941177,0.266666666666667,0.423529411764706;...
        0.949019607843137,0.650980392156863,0.121568627450980;...
        0.956862745098039,0.572549019607843,0.474509803921569;...
        0.231372549019608,0.490196078431373,0.717647058823529];  %设置一个颜色库
        %% 开始绘图
        %参数依次为数据矩阵、颜色设置、标记符
        box_figure = boxplot(box_plot','color',[0 0 0],'Symbol','o');
        %设置线宽
        set(box_figure,'Linewidth',1.2);
        boxobj = findobj(gca,'Tag','Box');
        for i = 1:5
            patch(get(boxobj(i),'XData'),get(boxobj(i),'YData'),mycolor(i,:),'FaceAlpha',0.5,...
                'LineWidth',1.1);
        end
        set(gca,'XTickLabel',{'FFFDBO','GODBO','QHDBO','DBO'});
        title(['F',num2str(F(func_num))])
        hold on
    end 
end

if exist('result.xls','file')
    delete('result.xls')
end

if exist('ranksumresult.xls','file')
    delete('ranksumresult.xls')
end

%% 将标准差，平均值，最优值等结果写入elcex中
A = string();
for i = 1:length(F)
    str = string(['F',num2str(F(i))]);
    A(5*(i-1)+1:5*i,1)= [str;str;str;str;str];
    A(5*(i-1)+1:5*i,2)= ["平均值";"标准差";"最优值";"最差值";"中值"];
end
A = cellstr (A);
A = [A,num2cell(RESULT)];
title = {" "," ","FFFDBO","MDBO","GODBO","QHDBO","DBO"};
A = [title;A];
xlswrite('result.xls', A)


%% 将秩和检验结果写入elcex中
B = string();
for i = 1:length(F)
    str = string(['F',num2str(F(i))]);
    B(i,1)= str;
end
B = cellstr (B);
B = [B,num2cell(rank_sum_RESULT)];
title = {" ","MDBO","GODBO","QHDBO","DBO"};% 秩和检验是和改进的算法做比较,因此这里没有改进的算法
B = [title;B];
xlswrite('ranksumresult.xls', B)

rmpath(genpath(pwd))

