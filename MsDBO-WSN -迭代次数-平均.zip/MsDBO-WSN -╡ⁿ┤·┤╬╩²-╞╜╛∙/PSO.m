function [gBestScore,gBest,  cg_curve] = PSO(N, Max_Evals, lb, ub, dim, fobj)
    % PSO Parameters
    Vmax = ones(1, dim) .* (ub - lb) * 0.05; % 最大速度
    w = 0.8; % 惯性权重
    c1 = 1.5; % 学习因子1
    c2 = 1.5; % 学习因子2

    % 初始化
    vel = zeros(N, dim); % 粒子的速度
    pBestScore = inf(N, 1); % 各个粒子的个体最优适应度
    pBest = zeros(N, dim); % 各个粒子的个体最优位置
    gBest = zeros(1, dim); % 全局最优位置
    gBestScore = inf; % 全局最优适应度
    cg_curve = []; % 用于存储每次迭代的全局最优解适应度

    % 粒子位置随机初始化
    % pos = repmat(lb, N, 1) + rand(N, dim) .* repmat((ub - lb), N, 1);
    % 初始化种群
for i = 1:N
    pos(i, :) =  lb + (ub - lb) .* rand(1, dim);
      fitness = fobj(pos(i, :));
     % 更新个体最优解
            if pBestScore(i) > fitness
                pBestScore(i) = fitness; % 更新个体最佳适应度
                pBest(i, :) = pos(i, :); % 更新个体最佳位置
            end

            % 更新全局最优解
            if gBestScore > fitness
                gBestScore = fitness; % 更新全局最佳适应度
                gBest = pos(i, :); % 更新全局最佳位置
            end
end
    % 总的评估次数
    % evals_count = 0; 

    % 迭代计算（直到达到最大评估次数）
    for evals_count=1: Max_Evals
        % 确保粒子位置在边界内
        pos = max(min(pos, ub), lb);

        % 评估每个粒子的适应度
        for i = 1:N
            fitness = fobj(pos(i, :));
            
            % 更新个体最优解
            if pBestScore(i) > fitness
                pBestScore(i) = fitness; % 更新个体最佳适应度
                pBest(i, :) = pos(i, :); % 更新个体最佳位置
            end

            % 更新全局最优解
            if gBestScore > fitness
                gBestScore = fitness; % 更新全局最佳适应度
                gBest = pos(i, :); % 更新全局最佳位置
            end
        end

        % 更新每个粒子的速度和位置
        for i = 1:N
            vel(i, :) = w * vel(i, :) ...
                         + c1 * rand() * (pBest(i, :) - pos(i, :)) ...
                         + c2 * rand() * (gBest - pos(i, :));
                     
            % 限制速度
            vel(i, :) = max(min(vel(i, :), Vmax), -Vmax);
            pos(i, :) = pos(i, :) + vel(i, :);
        end

        % 存储当前评估后的全局最佳适应度
        cg_curve(evals_count) =gBestScore;% 可以使用 append 方式存储历史最佳适应度
    end
end
