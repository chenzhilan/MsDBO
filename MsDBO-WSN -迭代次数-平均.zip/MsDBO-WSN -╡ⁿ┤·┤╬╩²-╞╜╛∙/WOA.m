function [Leader_score,Leader_pos,  WOA_Convergence_curve] = WOA(N, Max_Evals, lb, ub, dim, fobj)

    % % 初始化领导者的位置和得分
    % Leader_pos = zeros(1, dim);
    % Leader_score = inf; % 设为inf以用于最小化问题

    % 初始化搜索代理的位置
    Positions = initialization(N, dim, ub, lb);
    for i = 1:N
       
        fit(i) = fobj(Positions (i, :));
    end
    
    
    [Leader_score, bestI] = min(fit);  % 全局最佳适应度
    Leader_pos = Positions(bestI, :);  % 全局最佳位置
    % 用于存储每次迭代的领导者得分
    WOA_Convergence_curve = zeros(1, Max_Evals);
    
    % 总的函数评价次数
    % evals_count = 0;

    % 主循环（直到达到最大评估次数）
    for evals_count =1: Max_Evals
        for i = 1:size(Positions, 1)

            % 边界处理
            Flag4ub = Positions(i,:) > ub;
            Flag4lb = Positions(i,:) < lb;
            Positions(i,:) = (Positions(i,:) .* (~(Flag4ub + Flag4lb))) + ub .* Flag4ub + lb .* Flag4lb;

            % 计算每个搜索代理的目标函数值
            fitness = fobj(Positions(i,:));
           
            % 更新领导者
            if fitness < Leader_score % 最小化问题
                Leader_score = fitness; % 更新领导者得分
                Leader_pos = Positions(i,:); % 更新领导者位置
            end
            
            % 检查是否达到最大评估次数
            if evals_count >= Max_Evals
                break;
            end
        end
        
        % % 如果达到最大评估次数，则跳出循环
        % if evals_count >= Max_Evals
        %     break;
        % end

        a = 2 - evals_count * (2 / Max_Evals); % a线性下降从2到0
        % a2 = -1 + evals_count * (-1 / Max_Evals); % a2线性下降从-1到-2

        % 更新搜索代理的位置
        for i = 1:size(Positions, 1)
            r1 = rand(); % 第一个随机数
            r2 = rand(); % 第二个随机数

            A = 2 * a * r1 - a;  % 向量 A
            C = 2 * r2;          % 向量 C

            b = 1;               % 参数 b
            l = 2 * rand - 1; % 随机参数 l
            p = rand();          % 概率 p

            for j = 1:size(Positions, 2)
                if p < 0.5   
                    if abs(A) >= 1
                        rand_leader_index = floor(N * rand() + 1);
                        X_rand = Positions(rand_leader_index, :);
                        D_X_rand = abs(C * X_rand(j) - Positions(i,j)); % 随机领导者距离
                        Positions(i,j) = X_rand(j) - A * D_X_rand;      % 位置更新
                    elseif abs(A) < 1
                        D_Leader = abs(C * Leader_pos(j) - Positions(i,j)); % 距离领导者
                        Positions(i,j) = Leader_pos(j) - A * D_Leader;      % 位置更新
                    end
                else
                    distance2Leader = abs(Leader_pos(j) - Positions(i,j));
                    Positions(i,j) = distance2Leader * exp(b * l) * cos(l * 2 * pi) + Leader_pos(j); % 更新位置
                end
            end
        end
        
        % 保存当前迭代的领导者得分
        WOA_Convergence_curve(evals_count) = Leader_score; 
    end
end

function positions = initialization(N, dim, ub, lb)
    % 在给定的上下界下随机初始化位置
    positions = lb + rand(N, dim) .* (ub - lb);
end
